//! DittoBench validator wire contract (HTTP).
//!
//! The harness-facing types — [`RunRequest`], [`ToolExecRequest`],
//! [`ToolExecResponse`], [`ObservedToolCall`], [`RunResponse`] (plus
//! `SeedRequest`/`SeedResponse` in `seed.rs`) — are byte-compatible with the Go
//! validator's wire contract (dittobench-api's `pkg/protocol/protocol.go`). The
//! validator on Bittensor subnet 118 (SN118) POSTs a [`RunRequest`] to the
//! miner's `/run` endpoint per case and expects a [`RunResponse`]. Datasets
//! ([`Dataset`]) and score shapes ([`CaseScore`], [`ScoreReport`]) here are a
//! **partial local subset** produced for offline practice — they mirror the Go
//! field names but are not the full validator report.
//!
//! Field naming: the Go side uses `snake_case` json tags throughout, so every
//! struct here uses `#[serde(rename_all = "snake_case")]` (which is also the
//! Rust default field casing, but we keep it explicit for safety).

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use serde_json::Value;

/// The benchmark contract selected by `cargo run -- evaluate` / `-- practice`
/// and the playground Submit tab. That path is a local subset, not live SN118
/// scoring. The one-command rehearsal (`uv run ditto practice`) sends the live
/// scoring version separately.
pub const ACTIVE_BENCH_VERSION: u32 = 9;

/// Inclusive floor of contracts this image will execute. Do not raise it:
/// older validators still send 8.
pub const MIN_SUPPORTED_BENCH_VERSION: u32 = 8;

/// Inclusive ceiling matching the scorer's advertised set. Bump this when
/// DittoBench advertises a new version so a submitted image does not 400
/// every `/run`. Accepting a version is not the same as activating it as
/// `ACTIVE_BENCH_VERSION`. The public wire contract stays at 9 with additive
/// optional fields (#1519, option A), so accepting 13 costs a deployed harness
/// nothing: a scored v13 run still sends `bench_version: 9`, and 13 is accepted
/// for local rehearsal and any validator that sends the contract version
/// directly. `ditto/tests/test_bench_version_pins.py` diffs this ceiling against
/// the shared `MAX_SUPPORTED_BENCH_VERSION` every other layer derives from.
pub const MAX_SUPPORTED_BENCH_VERSION: u32 = 13;

pub fn supports_bench_version(version: u32) -> bool {
    (MIN_SUPPORTED_BENCH_VERSION..=MAX_SUPPORTED_BENCH_VERSION).contains(&version)
}

/// An expected tool in a dataset case (Go: `ToolSpec`).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct ToolSpec {
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub required_args: Option<BTreeMap<String, String>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub forbidden_args: Option<Vec<String>>,
}

/// One tool-calling benchmark case (Go: `ToolCase`).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct ToolCase {
    pub id: String,
    pub category: String,
    pub prompt: String,
    pub expected_tools: Vec<ToolSpec>,
    pub max_tool_calls: i32,
    pub allow_extra_tools: bool,
    pub expected_behavior: String,
}

/// One seed memory pair for a memory case (local practice extension).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct SeedMemory {
    pub prompt: String,
    pub response: String,
    pub days_ago: i64,
}

/// A memory-recall benchmark case (local practice extension). The harness is
/// seeded with `seed_memories` and then asked `question`; the answer should
/// surface `expected_answer`.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct MemoryCase {
    pub id: String,
    pub question: String,
    pub expected_answer: String,
    pub seed_memories: Vec<SeedMemory>,
}

/// A (fresh, seeded) benchmark dataset (Go: `Dataset`, extended with
/// `memory_cases`).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct Dataset {
    pub seed: i64,
    pub generated_at: String,
    pub tool_cases: Vec<ToolCase>,
    #[serde(default)]
    pub memory_cases: Vec<MemoryCase>,
}

/// A tool schema sent to the harness for a case (Go: `ToolDefinition`).
/// Named `ToolDefWire` here to avoid confusion with the harness's own
/// `ditto_harness::types::ToolDefinition`.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct ToolDefWire {
    pub name: String,
    pub description: String,
    /// JSON schema for the tool input.
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub parameters: Value,
}

/// What the validator POSTs to the harness `/run` endpoint per case
/// (Go: `RunRequest`). Distinct from `ditto_harness::chat::RunRequest`.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct RunRequest {
    pub case_id: String,
    pub system_prompt: String,
    pub user_input: String,
    #[serde(default)]
    pub tools: Vec<ToolDefWire>,
    /// Required benchmark contract selector. See [`supports_bench_version`].
    #[serde(default)]
    pub bench_version: u32,
    /// Optional observed-execution URL served by the validator. When present,
    /// a harness should EXECUTE each non-memory
    /// catalog tool call by POSTing a [`ToolExecRequest`] here and using the
    /// returned [`ToolExecResponse::result`], instead of stubbing it locally. The
    /// validator then observes the real trajectory (rather than trusting
    /// self-report) and can score whether the answer incorporates returned
    /// content. Scored v8 tool cases always provide this endpoint; local
    /// memory-only practice may omit it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_endpoint: Option<String>,
    /// Optional (observed execution): the memory graph this case must be answered from
    /// (multi-graph isolation). Mirrors the `user_id` the haystack was seeded
    /// under; answer only from this user's memory, never leak another user's
    /// facts. Absent ⇒ the default single-user graph.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub user_id: Option<String>,
    /// Validator-minted, case-scoped v10 relay base URL. Additive and optional
    /// so older v10 scorers and non-concurrent runs keep the process-wide URL.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub inference_base_url: Option<String>,
}

/// One mock tool-execution call a harness POSTs to the validator-served
/// [`RunRequest::tool_endpoint`] (Go: `ToolExecRequest`). The validator returns a
/// deterministic, seed-derived [`ToolExecResponse`] and records the call as the
/// authoritative observed trajectory.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct ToolExecRequest {
    pub case_id: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub user_id: String,
    pub name: String,
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub args: Value,
    #[serde(default)]
    pub hop: i32,
}

/// The mock result the validator returns for a [`ToolExecRequest`] (Go:
/// `ToolExecResponse`). `result` is the tool output to reason over; `error` is
/// set (with `result` empty) for a tool the endpoint does not serve (a memory
/// tool) — treat it like a real tool error.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct ToolExecResponse {
    #[serde(default)]
    pub result: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub error: String,
}

/// A tool call the harness made (Go: `ObservedToolCall`).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct ObservedToolCall {
    pub name: String,
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub args: Value,
    #[serde(default)]
    pub hop: i32,
}

/// What the harness returns for a case (Go: `RunResponse`).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct RunResponse {
    pub final_text: String,
    pub tool_calls: Vec<ObservedToolCall>,
    pub prompt_tokens: i64,
    pub output_tokens: i64,
    pub latency_ms: i64,
    /// Optional short answer slot: the bare value `final_text` asserts (a
    /// name, number, or comma-separated list). The validator's deterministic
    /// grader matches this slot when present and falls back to `final_text`
    /// containment, so populating it removes prose-phrasing risk. EXTENSION
    /// POINT: extract it from your agent's output.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub answer: Option<String>,
    /// Optional grounded-decline flag: set true when the asked fact is not in
    /// memory. Correct on needle-absent cases; abstaining on an answerable
    /// case scores 0.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub abstain: Option<bool>,
}

/// The score for one case (Go: `CaseScore`).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct CaseScore {
    pub case_id: String,
    pub category: String,
    /// 0..1.
    pub tool_score: f64,
    /// 0..1 result-usage credit for a result-usage tool case (observed execution): whether
    /// the answer incorporated the value the executed tool returned. Omitted (0)
    /// for non-result-usage cases.
    #[serde(default, skip_serializing_if = "is_zero")]
    pub result_usage: f64,
    pub latency_ms: i64,
    pub called: Vec<String>,
    pub expected: Vec<String>,
    #[serde(default)]
    pub notes: Vec<String>,
}

fn is_zero(x: &f64) -> bool {
    *x == 0.0
}

/// The full result of scoring a run (Go: `ScoreReport`, extended with
/// `memory_mean`).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub struct ScoreReport {
    pub run_id: String,
    pub generated_at: String,
    /// 0..1 weighted composite.
    pub composite: f64,
    /// 0..1 mean tool score.
    pub tool_mean: f64,
    /// 0..1 fraction of memory cases answered correctly.
    pub memory_mean: f64,
    pub median_ms: i64,
    pub n: i32,
    pub per_case: Vec<CaseScore>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn run_request_uses_snake_case_keys() {
        let req = RunRequest {
            case_id: "c1".into(),
            system_prompt: "be helpful".into(),
            user_input: "hi".into(),
            tools: vec![ToolDefWire {
                name: "search_web".into(),
                description: "d".into(),
                parameters: serde_json::json!({"type": "object"}),
            }],
            bench_version: ACTIVE_BENCH_VERSION,
            ..Default::default()
        };
        let v = serde_json::to_value(&req).expect("serialize");
        let obj = v.as_object().expect("object");
        for key in [
            "case_id",
            "system_prompt",
            "user_input",
            "tools",
            "bench_version",
        ] {
            assert!(obj.contains_key(key), "missing key {key}");
        }
        assert_eq!(obj["bench_version"], ACTIVE_BENCH_VERSION);
        assert!(!obj.contains_key("tool_endpoint"));
        assert!(!obj.contains_key("user_id"));
    }

    #[test]
    fn v8_run_request_accepts_observed_execution_fields() {
        let json = r#"{
            "case_id": "web_result_usage-1-0",
            "system_prompt": "be helpful",
            "user_input": "figure on the Veltrix index?",
            "tools": [],
            "bench_version": 8,
            "tool_endpoint": "http://host.docker.internal:49222/tool",
            "user_id": "colleague"
        }"#;
        let req: RunRequest = serde_json::from_str(json).expect("deserialize");
        assert_eq!(
            req.tool_endpoint.as_deref(),
            Some("http://host.docker.internal:49222/tool")
        );
        assert_eq!(req.user_id.as_deref(), Some("colleague"));
        assert_eq!(req.bench_version, 8);
    }

    #[test]
    fn v9_run_request_accepts_only_opaque_runtime_capabilities() {
        let json = r#"{
            "case_id": "f0e310c2-8c21-42e1-9e85-17d34ca9d51a",
            "system_prompt": "be helpful",
            "user_input": "ordinary production-semantic question",
            "tools": [],
            "bench_version": 9,
            "tool_endpoint": "http://host.docker.internal:11436/v1/tools/opaque/tool",
            "user_id": "8ec86f06-e794-4d1c-a920-97d3fcf5ce8b"
        }"#;
        let req: RunRequest = serde_json::from_str(json).expect("deserialize v9 request");
        assert_eq!(req.bench_version, 9);
        assert!(supports_bench_version(req.bench_version));
        assert_eq!(req.case_id, "f0e310c2-8c21-42e1-9e85-17d34ca9d51a");
        assert_eq!(
            req.user_id.as_deref(),
            Some("8ec86f06-e794-4d1c-a920-97d3fcf5ce8b")
        );
    }

    #[test]
    fn v10_run_request_accepts_case_scoped_inference_capability() {
        let json = r#"{
            "case_id": "f0e310c2-8c21-42e1-9e85-17d34ca9d51a",
            "system_prompt": "be helpful",
            "user_input": "ordinary production-semantic question",
            "tools": [],
            "bench_version": 10,
            "inference_base_url": "http://host.docker.internal:11436/v1/inference/cases/opaque"
        }"#;
        let req: RunRequest = serde_json::from_str(json).expect("deserialize v10 request");
        assert!(supports_bench_version(req.bench_version));
        assert_eq!(
            req.inference_base_url.as_deref(),
            Some("http://host.docker.internal:11436/v1/inference/cases/opaque")
        );
    }

    #[test]
    fn supported_versions_do_not_implicitly_activate_v9_practice() {
        assert_eq!(ACTIVE_BENCH_VERSION, 9);
        assert!(supports_bench_version(8));
        assert!(supports_bench_version(9));
        assert!(supports_bench_version(10));
        assert!(supports_bench_version(11));
        assert!(supports_bench_version(12));
        assert!(supports_bench_version(13));
        assert!(!supports_bench_version(MIN_SUPPORTED_BENCH_VERSION - 1));
        // The next epoch after the ceiling is the canonical unsupported version;
        // it moves with the constant instead of being retyped each bump.
        assert!(!supports_bench_version(MAX_SUPPORTED_BENCH_VERSION + 1));
    }

    #[test]
    fn v13_run_request_is_additive_on_the_v9_wire() {
        // Bench v13 keeps publicWireBenchVersion at 9: a v13 run arrives with
        // bench_version 9 plus richer, still-optional fields (enum schemas on
        // the wire, a per-seed catalog). A v9-era decoder must accept all of
        // it unchanged, and a direct 13 must be in range too.
        let json = r#"{
            "case_id": "f0e310c2-8c21-42e1-9e85-17d34ca9d51a",
            "system_prompt": "be helpful",
            "user_input": "switch me to the midnight look",
            "tools": [{
                "name": "set_theme",
                "description": "Set the app color theme.",
                "parameters": {"type": "object", "properties": {"theme": {"type": "string",
                    "enum": ["system", "light", "dark", "midnight", "solarized"]}}, "required": ["theme"]}
            }, {
                "name": "nimit_docs_search",
                "description": "Search Nimit workspace docs. Not a live web search.",
                "parameters": {"type": "object", "properties": {"query": {"type": "string"}}}
            }],
            "bench_version": 9,
            "tool_endpoint": "http://host.docker.internal:11436/v1/tools/opaque/tool",
            "inference_base_url": "http://host.docker.internal:11436/v1/inference/cases/opaque"
        }"#;
        let req: RunRequest = serde_json::from_str(json).expect("deserialize v13-on-v9 request");
        assert!(supports_bench_version(req.bench_version));
        assert_eq!(req.tools.len(), 2);
        assert_eq!(
            req.tools[0].parameters["properties"]["theme"]["enum"][3],
            "midnight"
        );
        let direct: RunRequest =
            serde_json::from_str(&json.replace("\"bench_version\": 9", "\"bench_version\": 13"))
                .expect("deserialize direct v13 request");
        assert_eq!(direct.bench_version, 13);
        assert!(supports_bench_version(direct.bench_version));
    }

    #[test]
    fn tool_exec_round_trips() {
        let req = ToolExecRequest {
            case_id: "c1".into(),
            user_id: "miner".into(),
            name: "search_web".into(),
            args: serde_json::json!({"query": "x"}),
            hop: 0,
        };
        let back: ToolExecRequest =
            serde_json::from_str(&serde_json::to_string(&req).expect("ser")).expect("de");
        assert_eq!(req, back);
        // A served result and an error variant both parse.
        let ok: ToolExecResponse =
            serde_json::from_str(r#"{"result":"the Veltrix index reached 3,418 points"}"#)
                .expect("de");
        assert_eq!(ok.error, "");
        let err: ToolExecResponse = serde_json::from_str(
            r#"{"error":"tool not available via this endpoint: search_memories"}"#,
        )
        .expect("de");
        assert_eq!(err.result, "");
    }

    #[test]
    fn run_response_round_trips() {
        let resp = RunResponse {
            final_text: "answer".into(),
            tool_calls: vec![ObservedToolCall {
                name: "search_web".into(),
                args: serde_json::json!({"query": "x"}),
                hop: 0,
            }],
            prompt_tokens: 10,
            output_tokens: 5,
            latency_ms: 42,
            answer: Some("answer".into()),
            abstain: None,
        };
        let json = serde_json::to_string(&resp).expect("serialize");
        let back: RunResponse = serde_json::from_str(&json).expect("deserialize");
        assert_eq!(resp, back);
        // The answer and abstention slots remain optional within v8.
        let without_optional_slots: RunResponse =
            serde_json::from_str(r#"{"final_text":"x","tool_calls":[],"prompt_tokens":0,"output_tokens":0,"latency_ms":0}"#)
                .expect("deserialize response without optional slots");
        assert_eq!(without_optional_slots.answer, None);
        assert_eq!(without_optional_slots.abstain, None);
    }
}
